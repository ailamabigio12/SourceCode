﻿using System;
using System.Collections.Generic;

namespace StartASPdotnetCore.Model
{
    public class Post
    {
        public int PostId { get; set; }
        public string Title { get; set; }
        public int BlogId { get; set; }
        public virtual List<Blog> Blogs { get; set; }
    }
}
